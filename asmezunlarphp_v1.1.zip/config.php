<?php
$admin_pwd  = 'admin'; // y�netici �ifresi
$admin_email= 'admin@emaili.com';
$file_name	= 'data.txt'; // kay�t dosyas�. Bu dosyaya CHMOD 666 uygulay�n
$pname		= "XXXXXXX �lk��retim Okulu"; // sayfa ad�
$tformat	= "d/m/y H:i"; // tarih bi�imi
$lang       = 'tr'; // dil kodu
$chrset_iso	= 'ISO-8859-9'; // dil karakter kodu
$mpp		= 15; // Sayfaya mesaj say�s�
$sf		    = 0;  // Saat Fark�. Dakika olarak
$wait_time	= 90; //Yeni mesaj g�nderme i�in bekleme s�resi. saniye olarak
?>
