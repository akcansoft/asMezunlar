<?php

/************************
Mezunlar PHP script v1.1
� 2003-2006 Mesut Akcan

http://www.mesut.web.tr
makcan@gmail.com
3/6/2003

G�ncelleme : 12/06/2006
************************/

error_reporting(E_ERROR | E_PARSE);
session_start();
include ("config.php");
if ($admin_pwd == $_SESSION['reg_pwd']){
	$admin=TRUE;
	$admin_msg = "��k��";
	$log = "out";}
else{
     $admin=FALSE;
     $admin_msg = "Giri�";
     $log = "in";}
import_request_variables('P', 'p_');
import_request_variables('G', 'g_');
$action = $p_action;
if ( $action == ""){$action = $g_action;}
//////////--- ACTIONS ---//////////////////////////
switch ($action){
case "login": // Y�netici giri� form // Admin Login Form ***********************
     pheader("Y�netici Giri�i");
     echo "<h3>Y�netici Giri�</h3>
	 <form method=POST>Y�netici Parolas�:
     <input type=hidden name=action value=login2><input type=password name=pass>
     <input type=submit value='G�nder'></form>";
     break;
case "login2": // Y�NET�C� G�R�� // ADMiN LOGiN ********************************
     if ($p_pass == $admin_pwd){
 	$_SESSION['reg_pwd'] = $admin_pwd;
	header("Location: $PHP_SELF");
     }
     else{
	     pheader("Y�netici Giri� kontrol");
	     echo "<h3>Y�netici Giri� Kontrol</h3>";
	     echo "Parola ge�ersiz. Giri� yap�lmad�.<br><a class='buton' href=\"javascript:history.back()\">Geri D�n</a>";
	     echo "<a class='buton' href=\"$PHP_SELF\">Kay�tlar</a>";
     }
     break;
case "logout": // Y�netici ��k�� // Admin Logout *******************************
     unset($_SESSION['reg_pwd']);
     pheader("Y�netici ��k��");
     echo "Y�netici ��k��� yap�ld�<br>";
     echo "<a class='buton' href=\"$PHP_SELF\">Kay�tlar</a>";
     break;
case "form": // Mesaj G�nder Form // Send a message form ***********************
     pheader("Yeni Kay�t G�nder");
     $time = mktime();
	 $tf = $time - $_SESSION['reg_stime'];
     if ($tf > $wait_time){
     	$data = join('',file("form.htm"));
     	$trtable = array(
			"#BASLIK#" => "Kay�t Ekle",
			"<!--EKLE-->" => "",
			"#ICQ#" => "",
			"#ADI#" => "",
			"#YIL#" => "",
			"#YER#" => "",
			"#ISI#" => "",
			"#MESSENGER#" => "",
			"#EMAIL#" => "",
			"#WEB#" => "http://",
			"#MESAJ#" => "",
			"#ACT#" => "post");
         echo (strtr($data,$trtable));}
	else{
		$tf = $wait_time - $tf;
		echo "�zg�n�m Yeni bir kay�t eklemek i�in $tf saniye beklemelisiniz";
		echo "<br><a class='buton' href=\"$PHP_SELF\">Kay�tlar</a>";
		}
    break;
case "edit": // D�zenle Form // Edit message Form ******************************
	if ($admin){
     	pheader("Kay�t De�i�tir/Sil");
     	$data = file($file_name);
     	$data = array_reverse ($data);
     	list($time,$check,$ra,$name,$email,$yil,$yer,$isi,$icq,$messenger,$web,$mesaj) = split("\|",$data[$mno]);
     	$data2 = join('',file("form.htm"));
     	$data2 = ereg_replace("#pheader#","Kayd� D�zenle: De�i�tir/Sil",$data2);
     	$frm_ek  = "<input type=\"hidden\" name=\"time\" value=\"$time\">";
     	$frm_ek .= "<input type=\"hidden\" name=\"ra\" value=\"$ra\">";
        $frm_ek .= "<input type=\"hidden\" name=\"mno\" value=\"$mno\">";
        $frm_ek .= "<input type=\"hidden\" name=\"check\" value=\"$check\">";
     	$frm_ek .= "<input type=\"checkbox\" name=\"sil\" value=\"YES\"><font color=\"red\">Kayd� Sil</font>";
		$mesaj = ereg_replace("<br>","\n",$mesaj);
		$trtable = array(
			"<!--EKLE-->" => $frm_ek,
			"#BASLIK#" => "Kay�t De�i�tir/Sil",
			"#ADI#" => $name,
			"#EMAIL#" => $email,
			"#WEB#" => $web,
			"#YIL#" => $yil,
			"#YER#" => $yer,
			"#ISI#" => $isi,
			"#MESSENGER#" => $messenger,
			"#ICQ#" => $icq,
			"#MESAJ#" => $mesaj,
			"#ACT#" => "post2");
     	echo (strtr($data2,$trtable));
     }
    else{header ("Location: $PHP_SELF?action=login");}
    break;
case "post": // G�nder - Kaydet // Message Send - Save *************************
	$time = mktime();
        $p_name = strip_tags($p_name); // html kodlar� engelle
        $p_yil = strip_tags($p_yil);
        $p_yer = strip_tags($p_yer);
        $p_isi = strip_tags($p_isi);
	if (strlen($p_name) > 30){$p_name=substr($p_name,0,30);}
	if (!(isemail($p_email))){$p_email='';}
	if (!(isemail($p_messenger))){$p_messenger='';}
	if (!(isweb($p_web))){$p_web='';}
	if (($p_icq < 10000) or ($p_icq > 2147483646)){$p_icq='';}
	$p_mesaj = stripslashes($p_mesaj);
	$p_mesaj = ereg_replace("\|","&#124;",$p_mesaj);
	$p_mesaj = ereg_replace("\r","",$p_mesaj);
	$p_mesaj = ereg_replace("(\n)+","\n",$p_mesaj);
        $mail_msg = $p_mesaj;
	$p_mesaj = ereg_replace("\n","<br>",$p_mesaj);
	$data = fopen($file_name, "a");
	flock($data,2);
	// ip al
	$ip = userip();
	fwrite($data, "$time|0|$ip|$p_name|$p_email|$p_yil|$p_yer|$p_isi|$p_icq|$p_messenger|$p_web|$p_mesaj|\n");
	flock($data,3);
	fclose($data);
	$reg_stime = $time;
    $scriptadr = $HTTP_SERVER_VARS['HTTP_HOST'].$HTTP_SERVER_VARS['PHP_SELF'];
    $time = date($tformat,($sf*60+$time));
    $mail_msg .= "--\nTAR�H:$time\nIP:$ip\n$scriptadr";
	mail($admin_email, "Mezunlar sayfas� yeni kay�t $p_name", $mail_msg,
	  "From: $p_email\r\n"
	  ."Reply-To: $p_email\r\n"
	  ."X-Mailer: PHP/" . phpversion());
	$_SESSION['reg_stime'] = $time;
	header("Location: $PHP_SELF");
	break;
case "post2": // De�i�tir/Sil & Kaydet // Edit-Delete- Save ********************
    if ($admin){
     	$data = file($file_name);
     	$data = array_reverse ($data);
     	if ($p_sil=="YES"){
		   unset ($data[$p_mno]);
		}
     	else{
            $p_name = strip_tags($p_name);
            $p_yil = strip_tags($p_yil);
            $p_yer = strip_tags($p_yer);
            $p_isi = strip_tags($p_isi);

            if (strlen($p_name) > 30){$p_name=substr($p_name,0,30);}
       	    if (!(isemail($p_email))){$p_email='';}
	    if (!(isemail($p_messenger))){$p_messenger='';}
       	    if (!(isweb($p_web))){$p_web='';}
       	    $mesaj = stripslashes($p_mesaj);
       	    $mesaj = ereg_replace("\|","&#124;",$mesaj);
       	    $mesaj = ereg_replace("\r","\n",$mesaj);
       	    $mesaj = ereg_replace("(\n)+","\n",$mesaj);
       	    $mesaj = ereg_replace("\n","<br>",$mesaj);
       	    $data[$p_mno] = "$p_time|$p_check|$p_ra|$p_name|$p_email|$p_yil|$p_yer|$p_isi|$p_icq|$p_messenger|$p_web|$mesaj|\n";
     	 }
     	 $data = array_reverse ($data);
     	 $data = join('',$data);
     	 $data = ereg_replace("(\r)+","",$data);
     	 $dp = fopen($file_name, "w");
     	 flock($data,2);
     	 fwrite($dp,$data);
     	 flock($data,3);
     	 fclose($dp);
     	 header("Location: $PHP_SELF");
     }
     else{header ("Location: $PHP_SELF?action=login");}
     break;
case "onay": // Bekleyen Mesaj� onayla
     if ($admin){
		$data = file($file_name);
		$data = array_reverse ($data);
		list($time,$check,$ra,$name,$email,$yil,$yer,$isi,$icq,$messenger,$web,$mesaj) = split("\|",$data[$g_mno]);
		$data[$g_mno] = "$time|1|$ra|$name|$email|$yil|$yer|$isi|$icq|$messenger|$web|$mesaj|\n";
		$data = array_reverse ($data);
		$data = join('',$data);
		$data = ereg_replace("(\r)+","",$data);
		$dp = fopen($file_name, "w");
		flock($data,2);
		fwrite($dp,$data);
		flock($data,3);
		fclose($dp);
		header("Location: $PHP_SELF");
     }
     else{header ("Location: $PHP_SELF?action=login");}
     break;
case "araform" : //arama formunu a�
     pheader("Kay�tlarda Ara");
   	$data = join('',file("form.htm"));
   	$trtable = array(
	  "<!--EKLE-->" => "",
	  "#BASLIK#" => "Kay�tlarda Ara",
	  "#ICQ#" => "",
      "#ADI#" => "",
      "#YIL#" => "",
      "#YER#" => "",
      "#ISI#" => "",
      "#MESSENGER#" => "",
      "#EMAIL#" => "",
      "#WEB#" => "",
      "#MESAJ#" => "",
      "#ACT#" => "kayitara");
     echo (strtr($data,$trtable));
	 break;
case "kayitara":
	 pheader("Mezunlar Sayfas� Kay�tlar�");
     echo "<h3>$pname Mezunlar� Arama Sonu�lar�</h3>";
     if (file_exists($file_name)){    // dosya varsa
     	$data = file($file_name);
     	$msg_count = count($data);
    	}
     else{$msg_count = 0;}
     $bkayits=0;
     if ($msg_count){ // mesaj varsa
  	    //echo "<table width=100% bgColor=#000080 border=0 cellspacing=1 cellpadding=3>";
	    $tempf =join('',file("template.htm"));
     	$data = array_reverse ($data);
     	foreach ($data as $satir){
		list($time,$check,$ip,$name,$email,$yil,$yer,$isi,$icq,$messenger,$web,$mesaj) = split("\|",$satir);
  		$varname=1;$varyil=1;$varemail=1;$varyer=1;$varisi=1;$varicq=1;$varmessenger=1;$varweb=1;$varmesaj=1;
		if ($check){
			  /// ad
			  if ($p_name){if (!(eregi($p_name,$name))){$varname=0;}}
			  /// email
			  if ($p_email){if (!(eregi($p_email,$email))){$varemail=0;}}
			  /// y�l
			  if ($p_yil){if (!(eregi($p_yil,$yil))){$varyil=0;}}
			  /// yer
			  if ($p_yer){if (!(eregi($p_yer,$yer))){$varyer=0;}}
			  /// isi
			  if ($p_isi){if (!(eregi($p_isi,$isi))){$varisi=0;}}
			  /// icq
			  if ($p_icq){if (!(eregi($p_icq,$icq))){$varicq=0;}}
			  /// messenger
			  if ($p_messenger){if (!(eregi($p_messenger,$messenger))){$varmessenger=0;}}
			  /// web
			  if ($p_web){if (!(eregi($p_web,$web))){$varweb=0;}}
			  /// mesaj
			  if ($p_mesaj){if (!(eregi($p_mesaj,$mesaj))){$varmesaj=0;}}
			  ///
			  if ($varname and $varyil and $varemail and $varyer and $varisi and $varicq and $varmessenger and $varweb and $varmesaj){
			  //////////////// varsa mesajlar� listele ///////
				 $temp=$tempf;
		         if ($name==""){$name="Ad yaz�lmam��";}
		         $time = date($tformat,($sf*60+$time));
            	 $mesaj = stripslashes($mesaj);
		 $trtable = array(
     	             "<br>" => "\n",
     	             "<" => "&lt;",
     	             ">" => "&gt;",
     	             '"' => "&quot;",
     	             "'" => "&#039;");
		 $mesaj = strtr($mesaj,$trtable);
     	    	 $mesaj = eregi_replace("(^|[>[:space:]\n])([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])([<[:space:]\n]|$)","\\1<a href=\"\\2://\\3\\4\" target=\"_blank\">\\2://\\3\\4</a> ", $mesaj);
	    	 $mesaj = preg_replace("/([\n >\(])www((\.[\w\-_]+)+(:[\d]+)?((\/[\w\-_%]+(\.[\w\-_%]+)*)|(\/[~]?[\w\-_%]*))*(\/?(\?[&;=\w\+%]+)*)?(#[\w\-_]*)?)/", "\\1<a href=\"http://www\\2\">www\\2</a>", $mesaj);
	    	 $mesaj = ereg_replace("\n","<br>",$mesaj);
     	    	 $temp = ereg_replace('#time#',$time,$temp);
     	    	 $temp = ereg_replace('#name#',"$name",$temp);
				 $temp = ereg_replace('#edit#',$replace,$temp);
				 $temp = ereg_replace('#ip#',"<img border=0 src='img/ip.gif' alt='IP:$ip'></td>",$temp);
				 if ($email){$replace = "<a href=\"mailto:$email\"><img border=0 src='img/em.gif' alt='Email'></a>";}
				 else{$replace = '';}
				 $temp = ereg_replace('#email#',$replace,$temp);
				 if ($icq){$replace = "<img src=\"http://wwp.icq.com/scripts/online.dll?icq=$icq&img=5\" alt=\"ICQ# $icq\">";}
				 else{$replace = '';}
				 $temp = ereg_replace('#icq#',$replace,$temp);
				 if ($yil){$replace = "<b>$yil</b> mezunu";}
				 else{$replace = '';}
				 $temp = ereg_replace('#yil#',$replace,$temp);
				 if ($isi){$replace = "<br>��i:<b>$isi</b>";}
				 else{$replace = '';}
				 $temp = ereg_replace('#isi#',$replace,$temp);
				 if ($yer){$replace = "Oturdu�u yer:<b>$yer</b>";}
				 else{$replace = '';}
				 $temp = ereg_replace('#yer#',$replace,$temp);
				 if ($messenger){$replace = "<a href=\"#\" onclick=\"MsgrObj.AddContact(0, '$messenger'); return false;\"><img alt='$messenger listeme ekle' border=0 src='img/messenger.gif'></a>";}
				 else{$replace = '';}
				 $temp = ereg_replace('#messenger#',$replace,$temp);
				 if ($web){$replace = "<a href=\"$web\"><img border=0 src='img/web.gif' alt='Web sayfas�'></a>";}				 else{$replace = '';}
				 $temp = ereg_replace('#web#',$replace,$temp);
				 $temp = ereg_replace('#message#',$mesaj,$temp);
     			 echo $temp;
				 $bkayits ++;
     			 }
          }
	   }
	 }
	 echo "</table>";
     $links = "<a class='buton' href=\"$PHP_SELF\">Kay�tlar</a><a class='buton' href=\"$PHP_SELF?action=form\">Kay�t yap</a>";
     $links .= "<a class='buton' href=\"$PHP_SELF?action=araform\">Kay�tlarda Ara</a>";
     $links .= "<a class='buton' href=\"$PHP_SELF?action=log$log\">Y�netici $admin_msg</a>";
     $links .= "<br>Toplam : <b>$bkayits</b> kay�t bulundu";
     echo "$links<br>";
	 break;
default: // Mesajlar� listele // List Messages /////////////
     pheader("Mezunlar Sayfas� Kay�tlar�");
     echo "<h3>$pname Mezunlar�</h3>";
     if (file_exists($file_name)){    // dosya varsa
     	$data = file($file_name);
     	$msg_count = count($data);
     	}
     else{$msg_count = 0;} //dosya yok
     if(!$g_pno){$g_pno=0;}
     if($g_pno==0){$links = "<font class='buton' color=\"#AAAAAA\">&laquo; �nceki</font>";}
     else{$gcc = $g_pno -1; $links .= "<a class='buton' href=\"$PHP_SELF?pno=$gcc\">&laquo; �nceki</a>";}
     $gcc = $g_pno * $mpp  + $mpp;
     if ($msg_count > $gcc){
	 	$gcc = $g_pno + 1;
		$links .= "<a class='buton' href=\"$PHP_SELF?pno=$gcc\">Sonraki &raquo;</a>";
	 }
     else {
	 	  $links .= "<font class='buton' color=\"#AAAAAA\">Sonraki &raquo;</font>";
	 }
     $links .= "<a class='buton' href=\"$PHP_SELF?action=form\">Kay�t yap</a>";
     $links .= "<a class='buton' href=\"$PHP_SELF?action=araform\">Kay�tlarda Ara</a>";
     $links .= "<a class='buton' href=\"$PHP_SELF?action=log$log\">Y�netici $admin_msg</a>";
     $links .="<br>Toplam : <b>$msg_count</b> kay�t";
     echo "$links<br>";
     if ($msg_count){ // mesaj varsa
     	$data = array_reverse ($data);
     	$first_m = $g_pno * $mpp;
     	$last_m = $first_m + $mpp;
     	if ($last_m > $msg_count){$last_m=$msg_count;}
     	echo "<table width=100% bgColor=#000080 border=0 cellspacing=1 cellpadding=3>";
        $tempf =join('',file("template.htm"));
		for ($lno=$first_m; $lno<$last_m; $lno++){
			$temp = $tempf;
			list($time,$check,$ip,$name,$email,$yil,$yer,$isi,$icq,$messenger,$web,$mesaj) = split("\|",$data[$lno]);
			if ($name==""){$name="Ad yaz�lmam��";}
     	    $time = date($tformat,($sf*60+$time));
            $mesaj = stripslashes($mesaj);
			$trtable = array(
				 "<br>" => "\n",
				 "<" => "&lt;",
				 ">" => "&gt;",
				 '"' => "&quot;",
				 "'" => "&#039;");
			$mesaj = strtr($mesaj,$trtable);
     	    $mesaj = eregi_replace("(^|[>[:space:]\n])([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])([<[:space:]\n]|$)","\\1<a href=\"\\2://\\3\\4\" target=\"_blank\">\\2://\\3\\4</a> ", $mesaj);
	    	$mesaj = preg_replace("/([\n >\(])www((\.[\w\-_]+)+(:[\d]+)?((\/[\w\-_%]+(\.[\w\-_%]+)*)|(\/[~]?[\w\-_%]*))*(\/?(\?[&;=\w\+%]+)*)?(#[\w\-_]*)?)/", "\\1<a href=\"http://www\\2\">www\\2</a>", $mesaj);
	    	$mesaj = ereg_replace("\n","<br>",$mesaj);
     	    $temp = ereg_replace('#time#',$time,$temp);
     	    $temp = ereg_replace('#name#',"$name",$temp);
     	    if ($admin){ // y�netici giri� yapt�ysa
            	if ($check==0){$mesaj = "<font color=red><b>KAYIT ONAY BEKL�YOR !</b></font><br>$mesaj";}
				$replace  = "<a href=$PHP_SELF?action=edit&mno=$lno><img border=0 src='img/ed.gif' alt='D�zenle'></a> ";
				if ($check == 0){$replace .= "<a href=$PHP_SELF?action=onay&mno=$lno><img border=0 src='img/ok.gif' alt='Onayla'></a>";}
            }
            else { // y�netici giri� yapmam��
				if ($check==0){$mesaj = "<font color=red><b>KAYDINIZ ONAY BEKL�YOR !</b></font>";}
				$replace='';
				$ip = preg_replace("/(\d+)\.(\d+)\.(\d+)\.(\d+)/","$1.$2.$3.xxx",$ip);
            }
			$temp = ereg_replace('#edit#',$replace,$temp);
			$temp = ereg_replace('#ip#',"<img border=0 src='img/ip.gif' alt='IP:$ip'></td>",$temp);
			if ($email){$replace = "<a href=\"mailto:$email\"><img border=0 src='img/em.gif' alt='Email'></a>";}
			else{$replace = '';}
   			if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#email#',$replace,$temp);

			if ($icq){$replace = "<img src=\"http://wwp.icq.com/scripts/online.dll?icq=$icq&img=5\" alt=\"ICQ# $icq\">";}
			else{$replace = '';}
            if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#icq#',$replace,$temp);

			if ($yil){$replace = "<b>$yil</b> mezunu";}
			else{$replace = '';}
			if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#yil#',$replace,$temp);

			if ($isi){$replace = "<br>��i:<b>$isi</b>";}
			else{$replace = '';}
			if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#isi#',$replace,$temp);

			if ($yer){$replace = "Oturdu�u yer:<b>$yer</b>";}
			else{$replace = '';}
			if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#yer#',$replace,$temp);

			if ($messenger){$replace = "<a href=\"#\" onclick=\"MsgrObj.AddContact(0, '$messenger'); return false;\"><img alt='$messenger listeme ekle' border=0 src='img/messenger.gif'></a>";}
			else{$replace = '';}
			if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#messenger#',$replace,$temp);

			if ($web){$replace = "<a href=\"$web\"><img border=0 src='img/web.gif' alt='Web sayfas�'></a>";}
			else{$replace = '';}
            if (($admin==FALSE) and ($check==0)){$replace = '';}
			$temp = ereg_replace('#web#',$replace,$temp);
			
			$temp = ereg_replace('#message#',$mesaj,$temp);
     		echo $temp;
        }
     }
     else{echo "Kay�t yok<br>";}
     echo "</table>";
     echo "<br>$links";
}
echo "<hr width=50% noshade size=1 color=#000080><font face='Tahoma'><span style='font-size: 8px'>
<a href=\"http://www.mesut.web.tr\"><i>akcan</i>Soft</a> mezunlarPHP v1.1
</font></center></body></html>";
exit;

////////// FONKS�YONLAR ///////////////////////////
function isweb($web){
	 if (eregi("(^|[>[:space:]\n])([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])([<[:space:]\n]|$)", $web))
	 {return TRUE;}else {return FALSE;}
}
//////////// Email Do�ru mu /// IS EMAIL /////////////
function isemail($email){
	 if (eregi("^([a-z]|[0-9]|\.|-|_)+@([a-z]|[0-9]|\.|-|_)+\.([a-z]|[0-9]){2,3}$", $email) &&
	 !eregi("(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)", $email))
	 {return TRUE;}else {return FALSE;}
}
/////////// Web do�ru mu //// IS WEB /////////
function pheader ($ptitle){
global $lang,$chrset_win,$chrset_iso;
echo<<<SON
<html><head><title>$ptitle</title>
<meta http-equiv="Content-Language" content="$lang">
<meta http-equiv="Content-Type" content="text/html; charset=$chrset">
<link href="template.css" rel="stylesheet" type="text/css"></head><body><center>
SON;
}

// User IP //////////////////

function userip(){
   if (isSet($_SERVER)) {
       if (isSet($_SERVER["HTTP_X_FORWARDED_FOR"])) {
           $IP = $_SERVER["HTTP_X_FORWARDED_FOR"];
       } elseif (isSet($_SERVER["HTTP_CLIENT_IP"])) {
           $IP = $_SERVER["HTTP_CLIENT_IP"];
       } else {
           $IP = $_SERVER["REMOTE_ADDR"];
       }
   } else {
       if ( getenv( 'HTTP_X_FORWARDED_FOR' ) ) {
           $IP = getenv( 'HTTP_X_FORWARDED_FOR' );
       } elseif ( getenv( 'HTTP_CLIENT_IP' ) ) {
           $IP = getenv( 'HTTP_CLIENT_IP' );
       } else {
           $IP = getenv( 'REMOTE_ADDR' );
       }
   }
   return $IP;
}

