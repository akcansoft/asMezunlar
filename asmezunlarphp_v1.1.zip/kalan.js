// script by: Mesut Akcan // http://mesut.web.tr
function kalan(){
var msjtxt;
var msjgen;
var azalma;
var maxharf;
var kalanh;
maxharf = 1000;
if (document.form1.mesaj.value != null){
	msjtxt = document.form1.mesaj.value;
	msjgen = msjtxt.length;
	if (msjgen > maxharf){
		document.form1.mesaj.value=msjtxt.substring(0,maxharf);
		kalanh = 0;
	}
	else {
		kalanh = maxharf - msjgen;
	}
	document.form1.gen.value = kalanh;
	}
}
